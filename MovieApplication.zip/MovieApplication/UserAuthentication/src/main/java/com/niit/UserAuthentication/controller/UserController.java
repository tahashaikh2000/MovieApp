package com.niit.UserAuthentication.controller;

import com.niit.UserAuthentication.domain.User;
import com.niit.UserAuthentication.exceptions.UserAlreadyExistsException;
import com.niit.UserAuthentication.exceptions.UserNotFoundException;
import com.niit.UserAuthentication.service.JwtSecutiryTokenGeneratior;
import com.niit.UserAuthentication.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
@CrossOrigin
@RestController
@RequestMapping("/api/v2")
public class UserController {
    private UserService userService;
    private JwtSecutiryTokenGeneratior jwtSecutiryTokenGeneratior;

    @Autowired
    public UserController(UserService userService, JwtSecutiryTokenGeneratior jwtSecutiryTokenGeneratior) {
        this.userService = userService;
        this.jwtSecutiryTokenGeneratior = jwtSecutiryTokenGeneratior;
    }
    @PostMapping("/save")
    public ResponseEntity<?> saveUser(@RequestBody User user) throws  UserAlreadyExistsException {
        return new ResponseEntity<>(userService.saveUser(user),HttpStatus.CREATED);
    }
    @PostMapping("/login")
    public ResponseEntity userLogin(@RequestBody User user) throws UserNotFoundException {
        Map<String,String> map=null;
        try{
            User user1=userService.findByEmailIdAndPassword(user.getEmailId(),user.getPassword());
            if(user1.getEmailId().equals(user.getEmailId())){
                map= jwtSecutiryTokenGeneratior.generateToken(user);
            }
            return new ResponseEntity<>(map,HttpStatus.OK);
        }
        catch(UserNotFoundException u){
            throw new UserNotFoundException();
        }
        catch (Exception e){
            return new ResponseEntity<>("try after some time",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
