package com.niit.UserAuthentication.service;

import com.niit.UserAuthentication.domain.User;
import com.niit.UserAuthentication.exceptions.UserAlreadyExistsException;
import com.niit.UserAuthentication.exceptions.UserNotFoundException;
import com.niit.UserAuthentication.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    public UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User saveUser(User user) throws UserAlreadyExistsException{
//        return userRepository.save(user);
        return userRepository.save(user);
    }


    @Override
    public User findByEmailIdAndPassword(String emailId, String password) throws UserNotFoundException {
        User user=userRepository.findByEmailIdAndPassword(emailId,password);
        if(user==null){
            throw new UserNotFoundException();
        }
        return user;
    }
}
