package com.niit.UserAuthentication.service;

import com.niit.UserAuthentication.domain.User;
import com.niit.UserAuthentication.exceptions.UserAlreadyExistsException;
import com.niit.UserAuthentication.exceptions.UserNotFoundException;

public interface UserService {
    public User saveUser(User user) throws UserAlreadyExistsException;
    public User findByEmailIdAndPassword(String emailId, String Password) throws UserNotFoundException;
}
