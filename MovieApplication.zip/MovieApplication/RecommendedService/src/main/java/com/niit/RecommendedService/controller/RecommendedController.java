package com.niit.RecommendedService.controller;


import com.niit.RecommendedService.domain.Movie;
import com.niit.RecommendedService.domain.MovieList;
import com.niit.RecommendedService.domain.RecommendedMovie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api/v5")
public class RecommendedController {

    @Value("${api_key}")
    private String apikey;


    @Autowired
    RestTemplate restTemplate;

//    @RequestMapping("/movie/{movieId}/recommendations")
//    public ResponseEntity<?> getMovie(@PathVariable int movieId){
//        MovieList movieObj = restTemplate.getForObject("http://api.themoviedb.org/3/movie/"+movieId+ "/recommendations" +"?api_key="+ apikey, MovieList.class);// MovieDTO movieDTO = new MovieDTO(movieObj.getId(), movieObj.getOriginal_language(), movieObj.getTitle(), movieObj.getPopularity(), movieObj.getRelease_date());
//      //  movieRepository.save(movieObj);
//      //  producerMovies.sendMessage(movieDTO);//this n will send the movie data through RabbitMQ
//      //  return new ResponseEntity<>(movieRepository.save(movieObj),HttpStatus.CREATED);
//        System.out.println(movieObj);
//        return new ResponseEntity<>(movieObj, HttpStatus.OK);
//    }

    @GetMapping("/movie/{movieId}/recommendations")
    public ResponseEntity<?> getMovie(@PathVariable int movieId){
        List<Movie> movies = null;
//        for(int i=movieId;i<movieId+10;i++){
            Movie movie = restTemplate.getForObject("http://api.themoviedb.org/3/movie/"+movieId+ "/recommendations" +"?api_key="+ apikey, Movie.class);
           movies.add(movie);

        System.out.println(movies);
        return new ResponseEntity<>(movies,HttpStatus.OK);
    }

//    @RequestMapping("/movie/{movieId}/recommendations")
//    public List<RecommendedMovie> getRecommendedMovie(@PathVariable int movieId){
//        List<Movie> movies = null;
//        return movies.stream().map(p->{
//            Movie movieObj = restTemplate.getForObject("http://api.themoviedb.org/3/movie/"+p.getId()+ "/recommendations" +"?api_key="+ apikey, Movie.class);
//            return new RecommendedMovie(movieObj.getId(), movieObj.getOriginal_language(), movieObj.getTitle(), movieObj.getPopularity(), movieObj.getRelease_date());
//        })
//                .collect(Collectors.toList());
//    }


//    @RequestMapping("/movie/{movieId}/recommendations")
//    public List<RecommendedMovie> getRecommendedMovie(@PathVariable int movieId){
//        RecommendedMovie[] recommendedMovie = restTemplate.getForObject("http://api.themoviedb.org/3/movie/"+movieId+ "/recommendations" +"?api_key="+ apikey, RecommendedMovie[].class);
//        return Arrays.asList(recommendedMovie);
//    }


}
