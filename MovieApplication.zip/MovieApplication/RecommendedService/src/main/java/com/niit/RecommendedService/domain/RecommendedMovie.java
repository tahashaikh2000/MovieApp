package com.niit.RecommendedService.domain;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecommendedMovie {

    @Id
    private int id;
    private String original_language;
    private String title;
    private String popularity;
    private String release_date;
}
