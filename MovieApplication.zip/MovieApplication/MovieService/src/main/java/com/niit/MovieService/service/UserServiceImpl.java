package com.niit.MovieService.service;

//import com.niit.MovieService.domain.ProfileImage;
import com.niit.MovieService.domain.Movie;
import com.niit.MovieService.domain.User;
import com.niit.MovieService.exceptions.UserAlreadyExistsException;
import com.niit.MovieService.exceptions.UserNotFoundException;
import com.niit.MovieService.proxy.UserProxy;
import com.niit.MovieService.rabbitMQ.UserDTO;
import com.niit.MovieService.repository.MovieRepository;
import com.niit.MovieService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    MovieRepository movieRepository;
    UserRepository userRepository;
    UserProxy userProxy;

    @Autowired
    public UserServiceImpl( MovieRepository movieRepository,UserRepository userRepository, UserProxy userProxy) {
        this.movieRepository=movieRepository;
        this.userRepository = userRepository;
        this.userProxy = userProxy;
    }


//    @Override
//    public User registerUser(User user) throws UserAlreadyExistsException {
//      //  user.setUserImage(file.getBytes());
//        if (userRepository.findById(user.getEmailId()).isPresent()) {
//            throw new UserAlreadyExistsException();
//        }
//        ResponseEntity r = userProxy.saveUser(user);
//        System.out.println(r.getBody());
//        return userRepository.save(user);
//
//    }


    @Override
    public User saveUserWithImage(User user, MultipartFile file) throws UserAlreadyExistsException, IOException {
       user.setUserImage(file.getBytes());
       if(userRepository.findById(user.getEmailId()).isPresent()){
           throw new UserAlreadyExistsException();
       }
       userProxy.saveUser(user);
        return userRepository.save(user);
    }

    @Override
    public boolean deleteUser(String emailId) throws UserNotFoundException {
        boolean result = false;
        if (userRepository.findById(emailId).isEmpty()) {
            throw new UserNotFoundException();
        }
        userRepository.deleteById(emailId);
        result = true;
        return result;
   }

    @Override
    public User updateUser(User user, String emailId) throws UserNotFoundException {
        if(userRepository.findById(emailId).isPresent()){
           User user1 = userRepository.findById(emailId).get();
           user1.setPassword(user.getPassword());
           userRepository.save(user1);
            System.out.println("password is updated");
            return user1;
        }
        throw new UserNotFoundException();

    }

    @Override
    public List<Movie> getAllMovie() throws Exception {
        return movieRepository.findAll();
    }
}

