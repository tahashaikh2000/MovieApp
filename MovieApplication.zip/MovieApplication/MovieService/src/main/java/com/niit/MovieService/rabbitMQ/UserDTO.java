package com.niit.MovieService.rabbitMQ;

import com.niit.MovieService.domain.Favourites;
//import com.niit.MovieService.domain.ProfileImage;

import java.util.List;

public class UserDTO {

    private String emailId;
    private String firstName;
    private String lastName;
    private String password;
    private String phoneNo;
   // private ProfileImage profileImage;
    private List<Favourites> favouritesList;
}
