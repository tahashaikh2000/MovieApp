package com.niit.MovieService.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Lob;
import java.util.List;


@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    @Id
    private String emailId;
    private String firstName;
    private String lastName;
    private String password;
    private String phoneNo;
    //private ProfileImage profileImage;
    private List<Favourites> favouritesList;

    @Lob
    private byte[] userImage;
}
