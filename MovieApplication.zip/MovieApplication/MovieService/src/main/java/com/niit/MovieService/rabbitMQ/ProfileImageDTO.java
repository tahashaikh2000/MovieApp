package com.niit.MovieService.rabbitMQ;

public class ProfileImageDTO {
    private String imageId;
    private String imageUrl;
    private String caption;
}
