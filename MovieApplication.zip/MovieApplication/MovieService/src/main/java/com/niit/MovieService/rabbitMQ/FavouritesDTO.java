package com.niit.MovieService.rabbitMQ;

public class FavouritesDTO {

    private int id;
    private String original_language;
    private String title;
    private String popularity;
    private String release_date;
}
