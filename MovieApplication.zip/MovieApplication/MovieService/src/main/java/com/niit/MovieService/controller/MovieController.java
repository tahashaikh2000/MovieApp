package com.niit.MovieService.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.niit.MovieService.config.ProducerMovies;
import com.niit.MovieService.domain.Movie;

import com.niit.MovieService.domain.User;
import com.niit.MovieService.exceptions.UserAlreadyExistsException;
import com.niit.MovieService.exceptions.UserNotFoundException;
import com.niit.MovieService.proxy.UserProxy;
import com.niit.MovieService.rabbitMQ.MovieDTO;
import com.niit.MovieService.repository.MovieRepository;
import com.niit.MovieService.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api/v1")
public class MovieController {
    private UserProxy proxy;
    private MovieRepository movieRepository;
    private  RestTemplate restTemplate;//basic spring class for simultaneous client -side http access
    private ProducerMovies producerMovies;
     UserService userService;

    @Value("${api_key}")
    private String apikey;

    @Autowired
    public MovieController(UserProxy proxy, MovieRepository movieRepository, RestTemplate restTemplate,ProducerMovies producerMovies,UserService userService) {
        this.proxy = proxy;
        this.movieRepository = movieRepository;
        this.restTemplate = restTemplate;
        this.producerMovies=producerMovies;
        this.userService=userService;
    }

        @PostMapping("/registeruserimg")
    public ResponseEntity<?> addUserWithImage(@RequestParam(value = "user") String user, @RequestParam(value = "file") MultipartFile file) throws UserAlreadyExistsException , IOException
    {
        User user1 = new ObjectMapper().readValue(user,User.class);
        ResponseEntity responseEntity = new ResponseEntity(userService.saveUserWithImage(user1,file),HttpStatus.CREATED);

        return responseEntity;
    }

    //user register function and login
    //---------------------------------------------------------
//    @PostMapping("/register")
//    public ResponseEntity<?>registerUser(@RequestBody User user) throws UserAlreadyExistsException {
//        try{
//            return  new ResponseEntity<>(userService.registerUser(user), HttpStatus.CREATED);
//
//        }
//        catch (UserAlreadyExistsException e){
//            throw new UserAlreadyExistsException();
//        }
//        catch (Exception e){
//            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
//
//        }
//    }


    @PostMapping("/deleteuser/{emailId}")
    public ResponseEntity<?>deleteUser(@PathVariable String emailId) throws UserNotFoundException {
        try{
            return  new ResponseEntity<>(userService.deleteUser(emailId), HttpStatus.CREATED);

        }
        catch (UserNotFoundException e){
            throw new UserNotFoundException();
        }
        catch (Exception e){
            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    @PostMapping("/updatepassword/{emailId}")
    public ResponseEntity<?>updatePasssword(@PathVariable String emailId, @RequestBody User user) throws UserNotFoundException {
        try{
            return  new ResponseEntity<>(userService.updateUser(user,emailId), HttpStatus.CREATED);

        }
        catch (UserNotFoundException e){
            throw new UserNotFoundException();
        }
        catch (Exception e){
            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }
//------------------------------------------------------
//calling an external api///getting movie by Id and storing it in database
 @RequestMapping("/movie/{movieId}")
    public ResponseEntity<?> getMovie(@PathVariable int movieId){
                 Movie movieObj = restTemplate.getForObject("http://api.themoviedb.org/3/movie/"+movieId+"?api_key="+ apikey, Movie.class);
                 MovieDTO movieDTO = new MovieDTO(movieObj.getId(), movieObj.getOriginal_language(), movieObj.getTitle(),movieObj.getPoster_path(), movieObj.getPopularity(), movieObj.getRelease_date());
                 movieRepository.save(movieObj);
                 producerMovies.sendMessage(movieDTO);//this n will send the movie data through RabbitMQ
            return new ResponseEntity<>(movieRepository.save(movieObj), HttpStatus.CREATED);
        }

//    https://api.themoviedb.org/3/movie/popular?api_key=<<api_key>>&language=en-US&page=1
    @RequestMapping("/movie/popular")
    public ResponseEntity<?> getPopularMovies(){
        Class<List<Movie>> obj= (Class<List<Movie>>) Collections.<Movie>emptyList().getClass();

        System.out.println("api"+restTemplate.getForObject("http://api.themoviedb.org/3/movie/popular?api_key="+ apikey,obj));
        Movie movieObj=restTemplate.getForObject("http://api.themoviedb.org/3/movie/popular?api_key="+ apikey,Movie.class);
        System.out.println("M"+movieObj);
        MovieDTO movieDTO = new MovieDTO(movieObj.getId(), movieObj.getOriginal_language(), movieObj.getTitle(),movieObj.getPoster_path(), movieObj.getPopularity(), movieObj.getRelease_date());

        movieRepository.save(movieObj);
        producerMovies.sendMessage(movieDTO);
        return new ResponseEntity<>(movieRepository.save(movieObj), HttpStatus.CREATED);

    }

     @GetMapping("/movie/getAll")
    public  ResponseEntity<?> getMovies(){
        try{
            return new ResponseEntity<>(userService.getAllMovie(),HttpStatus.CREATED);
        }
        catch (Exception e){
            return  new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
