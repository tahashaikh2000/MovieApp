package com.niit.MovieService.rabbitMQ;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MovieDTO {
    private int id;
    private String original_language;
    private String title;
    private String poster_path;
    private String popularity;
    private String release_date;
}
