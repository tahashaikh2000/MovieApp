package com.niit.MovieService.service;

//import com.niit.MovieService.domain.ProfileImage;
import com.niit.MovieService.domain.Movie;
import com.niit.MovieService.domain.User;
import com.niit.MovieService.exceptions.UserAlreadyExistsException;
import com.niit.MovieService.exceptions.UserNotFoundException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface UserService {

     User saveUserWithImage(User user, MultipartFile file) throws UserAlreadyExistsException, IOException;
    // User registerUser(User user) throws UserAlreadyExistsException;
     boolean deleteUser(String emailId) throws UserNotFoundException;
     User updateUser(User user, String emailId) throws UserNotFoundException;
     List<Movie> getAllMovie()throws Exception;
}
