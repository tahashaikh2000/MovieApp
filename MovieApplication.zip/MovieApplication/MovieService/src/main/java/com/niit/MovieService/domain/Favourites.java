package com.niit.MovieService.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Favourites {
    @Id
    private int id;
    private String original_language;
    private String title;
    private String popularity;
    private String release_date;
}
