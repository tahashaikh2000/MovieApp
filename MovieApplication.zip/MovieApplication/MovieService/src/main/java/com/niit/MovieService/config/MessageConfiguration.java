package com.niit.MovieService.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableRabbit
public class MessageConfiguration {
    private String exchangeName = "movie_exchange";
    private String registerQueue = "movie_queue";
    private String userRegisterQueue = "user_queue";


    @Bean//direct exchange is an exchange which route message to queues based on msg routing key
    public DirectExchange directExchange() {
        return new DirectExchange(exchangeName);
    }

    @Bean
    public Queue registerQueue() {

        return new Queue(registerQueue);
    }//end of function

    @Bean
    public Queue userRegisterQueue() {

        return new Queue(userRegisterQueue);
    }//end of function

    @Bean//data form json to obj
    Jackson2JsonMessageConverter producerJacksonConvertor() {
        return new Jackson2JsonMessageConverter();
    }


    @Bean//convert msg to library
    RabbitTemplate rabbitTemplate(final ConnectionFactory connectionFactory) {//
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);

        rabbitTemplate.setMessageConverter(producerJacksonConvertor());
        return rabbitTemplate;
    }

    @Bean//creating bean of binding
    public Binding bindingUserRegister(Queue userRegisterQueue, DirectExchange exchange) {

        return BindingBuilder.bind(userRegisterQueue()).to(exchange).with("user_routing");

    }


    @Bean
    public Binding bindingUser(Queue registerQueue, DirectExchange exchange) {

        return BindingBuilder.bind(registerQueue()).to(exchange).with("movie_routing");

    }
}