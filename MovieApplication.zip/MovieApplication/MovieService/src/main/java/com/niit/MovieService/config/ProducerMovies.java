package com.niit.MovieService.config;

import com.niit.MovieService.rabbitMQ.MovieDTO;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProducerMovies {
    private RabbitTemplate rabbitTemplate;
    private DirectExchange exchange;

    @Autowired
    public void ProducerTrack(RabbitTemplate rabbitTemplate, DirectExchange exchange) {
        this.rabbitTemplate = rabbitTemplate;
        this.exchange = exchange;
    }

    public void sendMessage(MovieDTO movieDTO){

        rabbitTemplate.convertAndSend(exchange.getName(),"movie_routing",movieDTO);
    }
}
