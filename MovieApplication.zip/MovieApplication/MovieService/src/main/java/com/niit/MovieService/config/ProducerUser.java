package com.niit.MovieService.config;

import com.niit.MovieService.rabbitMQ.MovieDTO;
import com.niit.MovieService.rabbitMQ.UserDTO;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ProducerUser {

    private RabbitTemplate rabbitTemplate;
    private DirectExchange exchange;

    @Autowired
    public void ProducerTrack(RabbitTemplate rabbitTemplate, DirectExchange exchange) {
        this.rabbitTemplate = rabbitTemplate;
        this.exchange = exchange;
    }

    public void sendMessage(UserDTO userDTO){

        rabbitTemplate.convertAndSend(exchange.getName(),"user_routing",userDTO);
    }
}
