package com.niit.MovieService.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;

@Document
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties
public class Movie {
    @Id
    private int id;
    private String original_language;
    private String title;
    private String poster_path;
    private String popularity;
    private String release_date;
}
