package com.niit.FavouriteService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavouriteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
