package com.niit.FavouriteService.repository;

//import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.Movie;
import com.niit.FavouriteService.domain.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FavouriteRepository extends MongoRepository<Favourites,Integer> {


}
