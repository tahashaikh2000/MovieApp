package com.niit.FavouriteService.repository;

import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface UserRepository extends MongoRepository<User, String> {
    @Query("{favouritesList.title':{$in :[?0]}}}")
    User findMovieByTitle(String title);

}
