package com.niit.FavouriteService.service;

//import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.Movie;
import com.niit.FavouriteService.domain.User;
import com.niit.FavouriteService.exceptions.MovieAlreadyExistsException;
import com.niit.FavouriteService.exceptions.MovieNotFoundException;
import com.niit.FavouriteService.exceptions.UserNotFoundException;
import com.niit.FavouriteService.repository.FavouriteRepository;
import com.niit.FavouriteService.repository.MovieRepository;
import com.niit.FavouriteService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class FavouriteServiceImpl implements FavouriteService {


    FavouriteRepository favouriteRepository;
    UserRepository userRepository;
    MovieRepository movieRepository;
    @Autowired
    public FavouriteServiceImpl(FavouriteRepository favouriteRepository, UserRepository userRepository, MovieRepository movieRepository) {
        this.favouriteRepository = favouriteRepository;
        this.userRepository = userRepository;
        this.movieRepository = movieRepository;
    }

    @Override
    public User addMovieFav(String emailId, Movie movie) throws MovieNotFoundException, UserNotFoundException, MovieAlreadyExistsException {
        System.out.println(movie);
        System.out.println(emailId);
        if(userRepository.findById(emailId).isEmpty() ){
            throw new UserNotFoundException();
            }
        Favourites favourites = new Favourites(movie.getId(), movie.getOriginal_language(),movie.getTitle(),movie.getPoster_path(),movie.getPopularity(),movie.getRelease_date());
        System.out.println(favourites);
        User user = userRepository.findById(emailId).get();
        System.out.println("user "+  user);
        List<Favourites> favouritesList1;
        if(user.getFavouritesList()==null)
        {
            favouritesList1 = new ArrayList<>();
            user.setFavouritesList(Arrays.asList(favourites));
            System.out.println("list is null");
        }
        else {
            favouritesList1 = user.getFavouritesList();
            for (Favourites fav:favouritesList1){
                if (fav.getTitle().equalsIgnoreCase(movie.getTitle())){
                    System.out.println("exception ...");
                    throw new MovieAlreadyExistsException();
                }
            }
        }
        favouritesList1.add(favourites);
        user.setFavouritesList(favouritesList1);
        System.out.println("user"+ user);
//        return favouriteRepository.save(favourites);
        return userRepository.save(user);

    }


    @Override
    public User deleteFavMovie(String emailId,int id) throws MovieNotFoundException, UserNotFoundException {
        if(userRepository.findById(emailId).isEmpty()) {
            throw new UserNotFoundException();
        }
        User user=userRepository.findById(emailId).get();
        List<Favourites> favList=user.getFavouritesList();
        if(favList.removeIf(p->p.getId()==id)){
            System.out.println(favList);
            user.setFavouritesList(favList);
        }
        else {
            throw new MovieNotFoundException();
        }
        return userRepository.save(user);
    }


        @Override
        public List<Favourites> getAllFavMovie(String emailId) throws UserNotFoundException {
            if(userRepository.findById(emailId).isEmpty()){
                throw new UserNotFoundException();
            }
            System.out.println(userRepository.findById(emailId).get().getFavouritesList());

            return userRepository.findById(emailId).get().getFavouritesList();
    }

//    @Override
//    public User getFavMovieByTitle(String emailId,String title) throws MovieNotFoundException, UserNotFoundException {
//
//        if(userRepository.findById(emailId).isEmpty()){
//            throw new UserNotFoundException();
//        }
////        Favourites favourites = favouriteRepository.findMovieByTitle(title);
////        System.out.println("output"+favourites);
////        return favourites;
//        User user = userRepository.findMovieByTitle(title);
//        System.out.println(user);
//        return user;
//    }
}

