package com.niit.FavouriteService.controller;

import com.niit.FavouriteService.domain.Movie;
import com.niit.FavouriteService.domain.User;
import com.niit.FavouriteService.exceptions.MovieNotFoundException;
import com.niit.FavouriteService.exceptions.UserNotFoundException;
import com.niit.FavouriteService.service.FavouriteServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/v4")
public class FavouriteController {
    FavouriteServiceImpl favouriteService;
    @Autowired
    public FavouriteController(FavouriteServiceImpl favouriteService) {
        this.favouriteService = favouriteService;
    }

    @PostMapping("/fav/addFav/{emailId}")
    public ResponseEntity<?>addMovieToFav(@PathVariable String emailId, @RequestBody Movie movie) throws MovieNotFoundException {
        System.out.println("in controller ");
        System.out.println(movie);

        System.out.println(emailId);
        try{
            return new ResponseEntity<>(favouriteService.addMovieFav(emailId, movie), HttpStatus.CREATED);

        }
        catch (MovieNotFoundException e) {
            throw new MovieNotFoundException();
        }
        catch (Exception e){
            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @DeleteMapping("/fav/remove/{emailId}/{id}")
    public ResponseEntity<?>removeFromFav(@PathVariable String emailId,@PathVariable int id) throws MovieNotFoundException {
        try{
            return new ResponseEntity<>(favouriteService.deleteFavMovie(emailId,id),HttpStatus.OK);
        } catch (MovieNotFoundException e) {
            throw new MovieNotFoundException();
        }
        catch (Exception e){
            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/fav/getAll/{emailId}")
    public ResponseEntity<?>getAllMovies(@PathVariable String emailId) throws Exception {
        try {
            return new ResponseEntity<>(favouriteService.getAllFavMovie(emailId), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("try after sometime", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//        @GetMapping("fav/favtitle/{emailId}/{title}")
//        public ResponseEntity<?>getFavMovieByTitle(@PathVariable String emailId, @PathVariable String title) throws MovieNotFoundException {
//            try{
//                return new ResponseEntity<>(favouriteService.getFavMovieByTitle(emailId, title), HttpStatus.OK);
//            }
//            catch (MovieNotFoundException e) {
//                throw new MovieNotFoundException();
//            }
//            catch (Exception e){
//                return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//        }
}
