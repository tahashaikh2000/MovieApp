package com.niit.FavouriteService.rabbitMQ;

//import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.Movie;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;

import java.util.List;

@Data
@AllArgsConstructor
public class UserDTO {

    private String emailId;
    private String password;
    private List<Favourites> favouritesList;
}
