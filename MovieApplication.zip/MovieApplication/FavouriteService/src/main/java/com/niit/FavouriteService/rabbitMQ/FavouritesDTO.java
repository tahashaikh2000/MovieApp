//package com.niit.FavouriteService.rabbitMQ;
//
//import com.niit.FavouriteService.domain.Movie;
//import lombok.Data;
//import org.springframework.data.annotation.Id;
//
//import java.util.List;
//@Data
//public class FavouritesDTO {
//
//
//        @Id
////    @GeneratedValue(strategy = GenerationType.IDENTITY)
//        private String favId;
//        private List<Movie> favMovies;
//
//}
