package com.niit.FavouriteService.service;

//import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.Favourites;
import com.niit.FavouriteService.domain.Movie;
import com.niit.FavouriteService.domain.User;
import com.niit.FavouriteService.exceptions.MovieAlreadyExistsException;
import com.niit.FavouriteService.exceptions.MovieNotFoundException;
import com.niit.FavouriteService.exceptions.UserNotFoundException;

import java.util.List;

public interface FavouriteService {

    public User addMovieFav(String emailId, Movie movie) throws MovieNotFoundException, UserNotFoundException, MovieAlreadyExistsException;
    public User deleteFavMovie(String emailId,int id) throws MovieNotFoundException, UserNotFoundException;
    public List<Favourites> getAllFavMovie(String emailId) throws UserNotFoundException;
//    public User getFavMovieByTitle(String emailId,String title) throws MovieNotFoundException, UserNotFoundException;
}
