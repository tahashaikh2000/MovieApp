package com.niit.FavouriteService.config;

import com.niit.FavouriteService.domain.Movie;
import com.niit.FavouriteService.exceptions.MovieAlreadyExistsException;
import com.niit.FavouriteService.rabbitMQ.MovieDTO;
import com.niit.FavouriteService.repository.MovieRepository;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;

public class ConsumerMovie {

    @Autowired
    private MovieRepository movieRepository;
    @RabbitListener(queues = "movie_queue")
    public void getMovieFromRabbitMQ(MovieDTO movieDTO)throws MovieAlreadyExistsException {
        Movie movie=new Movie(movieDTO.getId(),movieDTO.getOriginal_language(),movieDTO.getTitle(),movieDTO.getPoster_path(),movieDTO.getPopularity(),movieDTO.getRelease_date());
        movieRepository.save(movie);
    }
}
