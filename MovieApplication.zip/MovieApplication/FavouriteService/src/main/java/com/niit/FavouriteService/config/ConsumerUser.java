package com.niit.FavouriteService.config;

import com.niit.FavouriteService.domain.Movie;
import com.niit.FavouriteService.domain.User;
import com.niit.FavouriteService.exceptions.MovieAlreadyExistsException;
import com.niit.FavouriteService.rabbitMQ.MovieDTO;
import com.niit.FavouriteService.rabbitMQ.UserDTO;
import com.niit.FavouriteService.repository.MovieRepository;
import com.niit.FavouriteService.repository.UserRepository;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;


public class ConsumerUser {


    @Autowired
    private UserRepository userRepository;
    @RabbitListener(queues = "user_queue")
    public void getUserFromRabbitMQ(UserDTO userDTO)throws MovieAlreadyExistsException {
        User user=new User(userDTO.getEmailId(),userDTO.getPassword(),userDTO.getFavouritesList());
        userRepository.save(user);
    }
}
