package com.niit.FavouriteService.repository;

import com.niit.FavouriteService.domain.Movie;
import com.niit.FavouriteService.domain.User;
import org.springframework.boot.web.embedded.undertow.UndertowServletWebServer;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieRepository extends MongoRepository<Movie, Integer>{}