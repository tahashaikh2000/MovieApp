package com.niit.SearchService.controller;

import com.niit.SearchService.domain.Movie;
import com.niit.SearchService.exceptions.MovieAlreadyExistsException;
import com.niit.SearchService.exceptions.MovieNotFoundException;
import com.niit.SearchService.repository.MovieRepository;
import com.niit.SearchService.service.MovieServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
@CrossOrigin
@RestController
@RequestMapping("/api/v3")
public class MovieController {
    MovieServiceImpl movieService;

    @Autowired
    MovieRepository movieRepository;


//    @Value("${api_key}")
//   private String apikey;
   // https://api.themoviedb.org/3/search/movie?api_key=9df4415adf8834f21e53ac5b806b601e&query=woman

    @GetMapping("/searchtitle/{title}")
    public ResponseEntity<?> getMovieTitle(@PathVariable String title){
        return new ResponseEntity<>(movieRepository.getMovieByTitle(title),HttpStatus.FOUND);
    }

    @GetMapping("/search/{popularity}")
    public ResponseEntity<?> getMoviePopularity(@PathVariable String popularity){
        return new ResponseEntity<>(movieRepository.getMovieByPopularity(popularity),HttpStatus.FOUND);
    }

    @GetMapping("/movie/{movie_id}/recommendations")
    public ResponseEntity<?> getRecommendedMovies(@PathVariable int movie_id){
        return new ResponseEntity<>(movieRepository.findById(movie_id),HttpStatus.FOUND);
    }
























//    @GetMapping("/movie/{movieId}")
//    public MovieList getRecommendedMovie(@PathVariable String movieId){
//        Results results = getRestTemplate.getForObject("https://api.themoviedb.org/3/search/movie/"+"?api_key=" + apikey+"&query="+movieId,
//                Results.class);
//        System.out.println(results);
//        MovieList movieList = new MovieList(results.getPage(), results.getTotalResult(),results.getTotalPages(),results.getResult());
//        System.out.println(movieList);
//        return movieList;
//    }

//    public ResponseEntity<?> getAllMovies(){
//        try {
//            return new ResponseEntity<>(getRestTemplate.getForObject())
////        }
//
//   @GetMapping("/temp")
//    public Movie temp() {
//       Movie movie =
//        movieRepository.save(getRestTemplate.getForObject("https://api.themoviedb.org/3/search/movie/"+"?api_key=" + apikey+"&query="+500,
//                Movie.class));
//       Movie movie1 = new Movie(movie.getId(), movie.getOriginal_language(), movie.getTitle(), movie.getPopularity(), movie.getRelease_date());
//     return movie1;
//    }


    }


















//    @PostMapping("/save")
//    public ResponseEntity<?> saveMovie(@RequestBody Movie movie) throws MovieAlreadyExistsException{
//        try{
//            return new ResponseEntity<>(movieService.saveMovie(movie),HttpStatus.CREATED);
//        }
//        catch (MovieAlreadyExistsException ex)
//        {
//            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//
//    @GetMapping("/get/name/{movieName}")
//    public ResponseEntity<?> searchByMovieName(@PathVariable String movieName) throws MovieNotFoundException{
//        try{
//            return new ResponseEntity<>(movieService.searchByMovieName(movieName), HttpStatus.OK);
//        }
//        catch (MovieNotFoundException ex)
//        {
//            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @GetMapping("/get/genre/{movieGenre}")
//    public ResponseEntity<?> searchByMovieGenre(@PathVariable String movieGenre) throws MovieNotFoundException{
//        try{
//            return new ResponseEntity<>(movieService.searchByMovieGenre(movieGenre), HttpStatus.OK);
//        }
//        catch (MovieNotFoundException ex)
//        {
//            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @GetMapping("/get/director/{movieDirector}")
//    public ResponseEntity<?> searchByMovieDirector(@PathVariable String movieDirector) throws MovieNotFoundException{
//        try{
//            return new ResponseEntity<>(movieService.searchByMovieDirector(movieDirector), HttpStatus.OK);
//        }
//        catch (MovieNotFoundException ex)
//        {
//            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @GetMapping("/get/rating/{movieRating}")
//    public ResponseEntity<?> searchByMovieRating(@PathVariable String movieRating) throws MovieNotFoundException{
//        try{
//            return new ResponseEntity<>(movieService.searchByMovieRating(movieRating), HttpStatus.OK);
//        }
//        catch (MovieNotFoundException ex)
//        {
//            return new ResponseEntity<>("try after sometime",HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @GetMapping("/getAll")
//    public ResponseEntity<?>getAllMovies()throws Exception{
//        return new ResponseEntity<>(movieService.getMovies(),HttpStatus.OK);
//    }

