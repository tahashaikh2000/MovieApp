package com.niit.SearchService.service;

import com.niit.SearchService.domain.Movie;
import com.niit.SearchService.exceptions.MovieAlreadyExistsException;
import com.niit.SearchService.exceptions.MovieNotFoundException;

import java.util.List;

public interface MovieService {













    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    public Movie saveMovie(Movie movie) throws MovieAlreadyExistsException;
//    public List<Movie> getMovies()throws Exception;
//    public Movie searchByMovieName(String movieName) throws MovieNotFoundException;
//    public List<Movie> searchByMovieGenre(String movieGenre) throws MovieNotFoundException;
//    public List<Movie> searchByMovieRating(String movieRating) throws MovieNotFoundException;
//    public List<Movie> searchByMovieDirector(String movieDirector) throws MovieNotFoundException;

}
