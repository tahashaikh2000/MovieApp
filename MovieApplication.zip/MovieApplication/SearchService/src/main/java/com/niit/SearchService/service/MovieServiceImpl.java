package com.niit.SearchService.service;

import com.niit.SearchService.domain.Movie;
import com.niit.SearchService.exceptions.MovieAlreadyExistsException;
import com.niit.SearchService.exceptions.MovieNotFoundException;
import com.niit.SearchService.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieServiceImpl implements MovieService{
    MovieRepository movieRepository;

    @Autowired
    public MovieServiceImpl(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }




























//    @Override
//    public Movie saveMovie(Movie movie) throws MovieAlreadyExistsException {
//        if (movieRepository.findById(movie.getMovieId()).isPresent() ){
//            throw new MovieAlreadyExistsException();
//        }
//        return movieRepository.save(movie);
//    }

//    @Override
//    public List<Movie> getMovies() throws Exception {
//        return movieRepository.findAll();
//    }

//    @Override
//    public Movie searchByMovieName(String movieName) throws MovieNotFoundException {
//        return movieRepository.findByMovieName(movieName);
//    }
//
//    @Override
//    public List<Movie> searchByMovieGenre(String movieGenre) throws MovieNotFoundException {
//        return movieRepository.findByMovieGenre(movieGenre);
//    }
//
//    @Override
//    public List<Movie> searchByMovieRating(String movieRating) throws MovieNotFoundException {
//        return movieRepository.findByMovieRating(movieRating);
//    }
//
//    @Override
//    public List<Movie> searchByMovieDirector(String movieDirector) throws MovieNotFoundException {
//        return movieRepository.findByMovieDirector(movieDirector);
//    }
}
