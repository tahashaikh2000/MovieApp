package com.niit.SearchService.rabbitMQ;

import lombok.Data;
import org.springframework.data.annotation.Id;


@Data
public class MovieDTO {
    private int id;
    private String original_language;
    private String title;
    private String poster_path;
    private String popularity;
    private String release_date;
}