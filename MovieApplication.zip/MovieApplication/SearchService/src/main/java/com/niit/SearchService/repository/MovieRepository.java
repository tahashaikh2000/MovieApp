package com.niit.SearchService.repository;

import com.niit.SearchService.domain.Movie;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieRepository extends MongoRepository<Movie,Integer> {

    public Movie getMovieByTitle(String title);
    public Movie getMovieByPopularity(String popularity);
//    public List<Movie> getRecommendedMovie(int movie_id);














 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     public Movie findByMovieName(String movieName);
//    @Query("{'movieGenre':{$in :[?0]}}}")
//    public List<Movie> findByMovieGenre(String movieGenre);
//    @Query("{'movieDirector':{$in :[?0]}}}")
//    public List<Movie> findByMovieDirector(String movieDirector);
//    @Query("{'movieRating':{$in :[?0]}}}")
//    public List<Movie> findByMovieRating(String movieRating);
}
