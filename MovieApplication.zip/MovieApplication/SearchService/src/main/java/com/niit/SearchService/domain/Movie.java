package com.niit.SearchService.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import org.springframework.data.annotation.Id;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Data
@AllArgsConstructor
public class Movie {
    @Id
    private int id;
    private String original_language;
    private String title;
    private String poster_path;
    private String popularity;
    private String release_date;



}
